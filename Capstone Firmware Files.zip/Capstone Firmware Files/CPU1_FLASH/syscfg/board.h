/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef BOARD_H
#define BOARD_H

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//
// Included Files
//

#include "driverlib.h"
#include "device.h"

//*****************************************************************************
//
// PinMux Configurations
//
//*****************************************************************************

//
// CLB_OUTPUTXBAR1 -> SA1_Output Pinmux
//
//
// CLB_OUTPUTXBAR1 - GPIO Settings
//
#define GPIO_PIN_CLB_OUTPUTXBAR1 40
#define SA1_Output_CLBOUTPUTXBAR_GPIO 40
#define SA1_Output_CLBOUTPUTXBAR_PIN_CONFIG GPIO_40_CLB_OUTPUTXBAR1

//
// CLB_OUTPUTXBAR2 -> SA2_Output Pinmux
//
//
// CLB_OUTPUTXBAR2 - GPIO Settings
//
#define GPIO_PIN_CLB_OUTPUTXBAR2 41
#define SA2_Output_CLBOUTPUTXBAR_GPIO 41
#define SA2_Output_CLBOUTPUTXBAR_PIN_CONFIG GPIO_41_CLB_OUTPUTXBAR2

//
// CLB_OUTPUTXBAR3 -> SB1_Output Pinmux
//
//
// CLB_OUTPUTXBAR3 - GPIO Settings
//
#define GPIO_PIN_CLB_OUTPUTXBAR3 93
#define SB1_Output_CLBOUTPUTXBAR_GPIO 93
#define SB1_Output_CLBOUTPUTXBAR_PIN_CONFIG GPIO_93_CLB_OUTPUTXBAR3

//
// CLB_OUTPUTXBAR4 -> SB2_Output Pinmux
//
//
// CLB_OUTPUTXBAR4 - GPIO Settings
//
#define GPIO_PIN_CLB_OUTPUTXBAR4 94
#define SB2_Output_CLBOUTPUTXBAR_GPIO 94
#define SB2_Output_CLBOUTPUTXBAR_PIN_CONFIG GPIO_94_CLB_OUTPUTXBAR4

//
// CLB_OUTPUTXBAR5 -> SC1_Output Pinmux
//
//
// CLB_OUTPUTXBAR5 - GPIO Settings
//
#define GPIO_PIN_CLB_OUTPUTXBAR5 36
#define SC1_Output_CLBOUTPUTXBAR_GPIO 36
#define SC1_Output_CLBOUTPUTXBAR_PIN_CONFIG GPIO_36_CLB_OUTPUTXBAR5

//
// CLB_OUTPUTXBAR6 -> SC2_Output Pinmux
//
//
// CLB_OUTPUTXBAR6 - GPIO Settings
//
#define GPIO_PIN_CLB_OUTPUTXBAR6 96
#define SC2_Output_CLBOUTPUTXBAR_GPIO 96
#define SC2_Output_CLBOUTPUTXBAR_PIN_CONFIG GPIO_96_CLB_OUTPUTXBAR6

//
// CLB_OUTPUTXBAR7 -> SD1_Output Pinmux
//
//
// CLB_OUTPUTXBAR7 - GPIO Settings
//
#define GPIO_PIN_CLB_OUTPUTXBAR7 45
#define SD1_Output_CLBOUTPUTXBAR_GPIO 45
#define SD1_Output_CLBOUTPUTXBAR_PIN_CONFIG GPIO_45_CLB_OUTPUTXBAR7

//
// CLB_OUTPUTXBAR8 -> SD2_Output Pinmux
//
//
// CLB_OUTPUTXBAR8 - GPIO Settings
//
#define GPIO_PIN_CLB_OUTPUTXBAR8 98
#define SD2_Output_CLBOUTPUTXBAR_GPIO 98
#define SD2_Output_CLBOUTPUTXBAR_PIN_CONFIG GPIO_98_CLB_OUTPUTXBAR8

//
// EPWM1 -> EPWM1_Master Pinmux
//
//
// EPWM1_A - GPIO Settings
//
#define GPIO_PIN_EPWM1_A 0
#define EPWM1_Master_EPWMA_GPIO 0
#define EPWM1_Master_EPWMA_PIN_CONFIG GPIO_0_EPWM1_A
//
// EPWM1_B - GPIO Settings
//
#define GPIO_PIN_EPWM1_B 1
#define EPWM1_Master_EPWMB_GPIO 1
#define EPWM1_Master_EPWMB_PIN_CONFIG GPIO_1_EPWM1_B

//
// EPWM2 -> EPWM2_trigger Pinmux
//
//
// EPWM2_A - GPIO Settings
//
#define GPIO_PIN_EPWM2_A 2
#define EPWM2_trigger_EPWMA_GPIO 2
#define EPWM2_trigger_EPWMA_PIN_CONFIG GPIO_2_EPWM2_A
//
// EPWM2_B - GPIO Settings
//
#define GPIO_PIN_EPWM2_B 3
#define EPWM2_trigger_EPWMB_GPIO 3
#define EPWM2_trigger_EPWMB_PIN_CONFIG GPIO_3_EPWM2_B
//
// GPIO60 - GPIO Settings
//
#define polarity_GPIO_PIN_CONFIG GPIO_60_GPIO60
//
// GPIO61 - GPIO Settings
//
#define wall_edge_GPIO_PIN_CONFIG GPIO_61_GPIO61
//
// GPIO62 - GPIO Settings
//
#define enable_GPIO_PIN_CONFIG GPIO_62_GPIO62

//*****************************************************************************
//
// CLB Configurations
//
//*****************************************************************************
#define CLB_Main_Control_BASE CLB1_BASE
void CLB_Main_Control_init();
#define CLB_Combine_BASE CLB2_BASE
void CLB_Combine_init();
#define SA_SB_Signals_BASE CLB3_BASE
void SA_SB_Signals_init();
#define SC_SD_Signals_BASE CLB4_BASE
void SC_SD_Signals_init();
//
// Tile Configurations for all CLBs are in this file
//
#include "clb_config.h"

//*****************************************************************************
//
// CLBINPUTXBAR Configurations
//
//*****************************************************************************
#define CLB_Polarity_SOURCE 60
#define CLB_Polarity_INPUT XBAR_INPUT1
void CLB_Polarity_init();
#define CLB_edge_SOURCE 61
#define CLB_edge_INPUT XBAR_INPUT2
void CLB_edge_init();
#define CLB_enable_SOURCE 62
#define CLB_enable_INPUT XBAR_INPUT3
void CLB_enable_init();
#define CLB_Master_EPWM_SOURCE 0
#define CLB_Master_EPWM_INPUT XBAR_INPUT5
void CLB_Master_EPWM_init();

//*****************************************************************************
//
// CLBOUTPUTXBAR Configurations
//
//*****************************************************************************
void SA1_Output_init();
#define SA1_Output XBAR_OUTPUT1
#define SA1_Output_ENABLED_MUXES (XBAR_MUX16)
void SA2_Output_init();
#define SA2_Output XBAR_OUTPUT2
#define SA2_Output_ENABLED_MUXES (XBAR_MUX17)
void SB1_Output_init();
#define SB1_Output XBAR_OUTPUT3
#define SB1_Output_ENABLED_MUXES (XBAR_MUX18)
void SB2_Output_init();
#define SB2_Output XBAR_OUTPUT4
#define SB2_Output_ENABLED_MUXES (XBAR_MUX19)
void SC1_Output_init();
#define SC1_Output XBAR_OUTPUT5
#define SC1_Output_ENABLED_MUXES (XBAR_MUX24)
void SC2_Output_init();
#define SC2_Output XBAR_OUTPUT6
#define SC2_Output_ENABLED_MUXES (XBAR_MUX25)
void SD1_Output_init();
#define SD1_Output XBAR_OUTPUT7
#define SD1_Output_ENABLED_MUXES (XBAR_MUX26)
void SD2_Output_init();
#define SD2_Output XBAR_OUTPUT8
#define SD2_Output_ENABLED_MUXES (XBAR_MUX27)

//*****************************************************************************
//
// EPWM Configurations
//
//*****************************************************************************
#define EPWM1_Master_BASE EPWM1_BASE
#define EPWM1_Master_TBPRD 1999
#define EPWM1_Master_COUNTER_MODE EPWM_COUNTER_MODE_UP
#define EPWM1_Master_TBPHS 0
#define EPWM1_Master_CMPA 999
#define EPWM1_Master_CMPB 0
#define EPWM1_Master_CMPC 0
#define EPWM1_Master_CMPD 0
#define EPWM1_Master_DBRED 0
#define EPWM1_Master_DBFED 0
#define EPWM1_Master_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EPWM1_Master_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EPWM1_Master_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define EPWM2_trigger_BASE EPWM2_BASE
#define EPWM2_trigger_TBPRD 1999
#define EPWM2_trigger_COUNTER_MODE EPWM_COUNTER_MODE_UP
#define EPWM2_trigger_TBPHS 0
#define EPWM2_trigger_CMPA 0
#define EPWM2_trigger_CMPB 0
#define EPWM2_trigger_CMPC 0
#define EPWM2_trigger_CMPD 0
#define EPWM2_trigger_DBRED 0
#define EPWM2_trigger_DBFED 0
#define EPWM2_trigger_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EPWM2_trigger_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EPWM2_trigger_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED

//*****************************************************************************
//
// FLASH Configurations
//
//*****************************************************************************
#define myFMC0_BASE FLASH0CTRL_BASE
#define myFMC0_ECCBASE FLASH0ECC_BASE
#define myFMC0_WAITSTATES 4

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
#define polarity 60
void polarity_init();
#define wall_edge 61
void wall_edge_init();
#define enable 62
void enable_init();

//*****************************************************************************
//
// SYNC Scheme Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// SYSCTL Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// Board Configurations
//
//*****************************************************************************
void	Board_init();
void	CLB_init();
void	CLB_INPUTXBAR_init();
void	CLB_OUTPUTXBAR_init();
void	EPWM_init();
void	FLASH_init();
void	GPIO_init();
void	SYNC_init();
void	SYSCTL_init();
void	PinMux_init();

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif  // end of BOARD_H definition

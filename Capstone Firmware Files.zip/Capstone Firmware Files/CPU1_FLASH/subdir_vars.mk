################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
./syscfg/clb_sim.cpp 

CMD_SRCS += \
../28p65x_generic_flash_lnk_cpu1.cmd 

SYSCFG_SRCS += \
../c2000.syscfg 

LIB_SRCS += \
C:/ti/c2000/C2000Ware_26_01_00_00/driverlib/f28p65x/driverlib/ccs/Debug/driverlib.lib 

ASM_SRCS += \
C:/ti/c2000/C2000Ware_26_01_00_00/device_support/f28p65x/common/source/f28p65x_codestartbranch.asm 

C_SRCS += \
./syscfg/board.c \
./syscfg/device.c \
./syscfg/clb_config.c \
./syscfg/c2000ware_libraries.c \
../empty_driverlib_main.c 

GEN_FILES += \
./syscfg/board.c \
./syscfg/board.opt \
./syscfg/device.c \
./syscfg/clb_config.c \
./syscfg/clb_sim.cpp \
./syscfg/c2000ware_libraries.opt \
./syscfg/c2000ware_libraries.c 

GEN_MISC_DIRS += \
./syscfg 

C_DEPS += \
./syscfg/board.d \
./syscfg/device.d \
./syscfg/clb_config.d \
./syscfg/c2000ware_libraries.d \
./empty_driverlib_main.d 

GEN_OPTS += \
./syscfg/board.opt \
./syscfg/c2000ware_libraries.opt 

OBJS += \
./syscfg/board.obj \
./syscfg/device.obj \
./syscfg/clb_config.obj \
./syscfg/clb_sim.obj \
./syscfg/c2000ware_libraries.obj \
./f28p65x_codestartbranch.obj \
./empty_driverlib_main.obj 

ASM_DEPS += \
./f28p65x_codestartbranch.d 

GEN_MISC_FILES += \
./syscfg/board.h \
./syscfg/board.cmd.genlibs \
./syscfg/board.json \
./syscfg/pinmux.csv \
./syscfg/epwm.dot \
./syscfg/device.h \
./syscfg/clb_config.h \
./syscfg/clb.dot \
./syscfg/clb_simulation.bat \
./syscfg/c2000ware_libraries.cmd.genlibs \
./syscfg/c2000ware_libraries.h \
./syscfg/clocktree.h 

CPP_DEPS += \
./syscfg/clb_sim.d 

GEN_MISC_DIRS__QUOTED += \
"syscfg" 

OBJS__QUOTED += \
"syscfg\board.obj" \
"syscfg\device.obj" \
"syscfg\clb_config.obj" \
"syscfg\clb_sim.obj" \
"syscfg\c2000ware_libraries.obj" \
"f28p65x_codestartbranch.obj" \
"empty_driverlib_main.obj" 

GEN_MISC_FILES__QUOTED += \
"syscfg\board.h" \
"syscfg\board.cmd.genlibs" \
"syscfg\board.json" \
"syscfg\pinmux.csv" \
"syscfg\epwm.dot" \
"syscfg\device.h" \
"syscfg\clb_config.h" \
"syscfg\clb.dot" \
"syscfg\clb_simulation.bat" \
"syscfg\c2000ware_libraries.cmd.genlibs" \
"syscfg\c2000ware_libraries.h" \
"syscfg\clocktree.h" 

C_DEPS__QUOTED += \
"syscfg\board.d" \
"syscfg\device.d" \
"syscfg\clb_config.d" \
"syscfg\c2000ware_libraries.d" \
"empty_driverlib_main.d" 

CPP_DEPS__QUOTED += \
"syscfg\clb_sim.d" 

GEN_FILES__QUOTED += \
"syscfg\board.c" \
"syscfg\board.opt" \
"syscfg\device.c" \
"syscfg\clb_config.c" \
"syscfg\clb_sim.cpp" \
"syscfg\c2000ware_libraries.opt" \
"syscfg\c2000ware_libraries.c" 

ASM_DEPS__QUOTED += \
"f28p65x_codestartbranch.d" 

SYSCFG_SRCS__QUOTED += \
"../c2000.syscfg" 

C_SRCS__QUOTED += \
"./syscfg/board.c" \
"./syscfg/device.c" \
"./syscfg/clb_config.c" \
"./syscfg/c2000ware_libraries.c" \
"../empty_driverlib_main.c" 

CPP_SRCS__QUOTED += \
"./syscfg/clb_sim.cpp" 

ASM_SRCS__QUOTED += \
"C:/ti/c2000/C2000Ware_26_01_00_00/device_support/f28p65x/common/source/f28p65x_codestartbranch.asm" 



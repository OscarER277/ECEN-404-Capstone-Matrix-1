//#############################################################################
//
// FILE:   empty_driverlib_main.c
//
//! \addtogroup driver_example_list
//! <h1>Empty Project Example</h1> 
//!
//! This example is an empty project setup for Driverlib development.
//!
//
//#############################################################################
//
//
// 
// C2000Ware v26.01.00.00
//
// Copyright (C) 2024 Texas Instruments Incorporated - http://www.ti.com
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//#############################################################################

//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"

volatile uint16_t adc_value;
volatile uint16_t adc_polarity_value;
volatile int16_t past_polarity;
volatile int16_t edge_switch;
volatile uint16_t epwm2_count = 0;

void initADC(void)
{
  SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_ADCA); //enable the ADC peripheral
  ADC_setPrescaler(ADCA_BASE, ADC_CLK_DIV_4_0); //sets the ADC clock
  ADC_setMode(ADCA_BASE,ADC_RESOLUTION_12BIT,ADC_MODE_SINGLE_ENDED); // sets 12-bit ADC mode
  ADC_setVREF(ADCA_BASE, ADC_REFERENCE_INTERNAL, ADC_REFERENCE_3_3V); //use internal references
  ADC_enableConverter(ADCA_BASE); //ppowers up the appropraite ADC harware, this case ADCA
  DEVICE_DELAY_US(1000); //ADC stabalizing time

  // signifys the Start of Conversion for the ADC inputs
  ADC_setupSOC(ADCA_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM2_SOCA, ADC_CH_ADCIN0, 20); // ADC0 - input from Diff amp

  ADC_setInterruptSource(ADCA_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
  ADC_enableInterrupt(ADCA_BASE, ADC_INT_NUMBER1);
  ADC_clearInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1);

}

void ADC_cal(void)
{

    adc_value = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER0);
    
    past_polarity = adc_polarity_value;

    if(adc_value > 930)
    {
        adc_polarity_value=0;
        GPIO_writePin(60, 0); // if higher than zero crossing place on positive leg
    }

    else if(adc_value < 910)
    {
        adc_polarity_value=1;
        GPIO_writePin(60, 1); // if lower than zero crossing place on negative leg
    }

    if (adc_polarity_value != past_polarity)
    {
        if(past_polarity == 0 && adc_polarity_value == 1)
        {
        GPIO_writePin(61, 1);
        }
        else if(past_polarity == 1 && adc_polarity_value == 0)
        {
        GPIO_writePin(61, 0);
        }
    }

}
//
// Main
//
void main(void)
{
    Device_init();
    Device_initGPIO();
    Interrupt_initModule();
    Board_init();
    C2000Ware_libraries_init();
    initADC();

    EINT;
    ERTM;

    while(1)
    {
        GPIO_writePin(62, 1);   // enable = 1
        epwm2_count = EPWM_getTimeBaseCounterValue(EPWM2_BASE);
        if(ADC_getInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1))
        {
            ADC_clearInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1);
            ADC_cal();
        }

        // Should Turn on SB1 and SB2
        //GPIO_writePin(26, 1);   // Polarity = 1
        //GPIO_writePin(24,1);  // zero-cross = 1
        //GPIO_writePin(27,0);  // edge = 0
        //GPIO_writePin(25, 1);   // enable = 1

        //DEVICE_DELAY_US(7500);  // 10 ms delay simulate 60 Hz data entry

        // Should Turn on SC1 and SC2
        //GPIO_writePin(26, 1);   // Polarity = 1
        //GPIO_writePin(24,1);  // zero-cross = 1 
        //GPIO_writePin(27,1);  // edge = 1
        //GPIO_writePin(25, 1);   // enable = 1

        //DEVICE_DELAY_US(7500);  // 10 ms delay

        // Should tunr on SD1 and SD2
        //GPIO_writePin(26, 0);   // Polarity = 0
        //GPIO_writePin(24,1);  // zero-cross = 1
        //GPIO_writePin(27,0);  // edge = 0
        //GPIO_writePin(25, 1);   // enable = 1

        //DEVICE_DELAY_US(7500);  // 10 ms delay

        // Should turn on SA1 and SA2
        //GPIO_writePin(26, 0);   // Polarity = 0
        //GPIO_writePin(24,1);  // zero-cross = 1
        //GPIO_writePin(27,1);  // edge = 1
        //GPIO_writePin(25, 1);   // enable = 1
        
        //DEVICE_DELAY_US(7500);  // 15 ms delay
    }
}

//
// End of File
//
